//
// Created by Avalle Dario, De Carlo Francesca, Fagnani Pietro
//

#ifndef PROGETTO_TIME_H
#define PROGETTO_TIME_H

#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>

using namespace std;

class Time {
public:
    Time();
    Time( const int &d, const int &m, const int &y );
    string str() const;
    bool operator== ( const Time & to_compare ) const;
    bool operator!= ( const Time & to_compare ) const;
    bool operator> ( const Time & to_compare ) const;
    bool operator< ( const Time & to_compare ) const;
    friend std::ostream& operator<< ( std::ostream& stream, const Time& d );
    friend std::istream& operator>> ( std::istream& stream, Time &t );

private:
    int _hour;
    int _min;
    int _sec;
};

#endif //PROGETTO_TIME_H