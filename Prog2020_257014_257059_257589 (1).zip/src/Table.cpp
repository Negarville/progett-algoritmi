//
// Created by Avalle Dario, De Carlo Francesca, Fagnani Pietro
//

#include "Table.h"


Table::Table ( list<string>& column_info, const vector<campo*>& reference ) {
    _numrecords = 0;
                              //la lista in input sarà del tipo: _table_key ( informazioni )
    _table_key = *column_info.begin();                              //salva la _table_key della tabella
    column_info.pop_front();                                        //elimino la _table_key della tabella dalla lista
    list<string>::iterator iteratore = column_info.begin();
    while ( *iteratore != "PRIMARY" ) {
        bool not_null = false;
        bool auto_i = false;
        int auto_increment = 0;

        string key = *iteratore;                                         //leggo la _table_key identificatrice della colonna
        iteratore++;
        string type_of_template = *iteratore;                            //leggo il tipo della colonna
        iteratore++;
        if ( iteratore != column_info.end() ) {
            if (*iteratore == "NOT_NULL") {                                    //salvo l'informazione sull'eventuale "NOT NULL"
                not_null = true;
                iteratore++;
            }
        }
        if ( iteratore != column_info.end() ) {
            if (*iteratore == "AUTO_INCREMENT") {                              //salvo l'informazione sull'eventuale "AUTO INCREMENT"
                auto_i = true;
                auto_increment = atoi((*++iteratore).data());
                iteratore++;
            }
        }

        //costruisco un nuovo campo
        campo nuovo_campo;
        nuovo_campo.key = key;
        nuovo_campo.is_auto = auto_i;
        nuovo_campo.auto_increment = auto_increment; //diventa 1
        nuovo_campo.is_not_null = not_null;
        nuovo_campo.tipo = convertStringToType( type_of_template );

        switch ( nuovo_campo.tipo ) {
            case INT:
                nuovo_campo.ptr = (void*) new Column<int>();
                break;
            case FLOAT:
                nuovo_campo.ptr = (void*) new Column<float>();
                break;
            case CHAR:
                nuovo_campo.ptr = (void*) new Column<char>();
                break;
            case TEXT:
                nuovo_campo.ptr = (void*) new Column<string>();
                break;
            case DATE:
                nuovo_campo.ptr = (void*) new Column<Date>();
                break;
            case TIME:
                nuovo_campo.ptr = (void*) new Column<Time>();
                break;
            default:
                break;
        }
        _fields.push_back( nuovo_campo );
    }

    _primary_key = *++iteratore;
    
    if ( ++iteratore != column_info.end() ) {
        int i = 0;
        //la parte rimanente di column_info è FOREIGN FOREIGN_KEY1 TABLE1 COLUMN1  FOREIGN_KEY2 TABLE2 COLUMN2 ecc..
        while ( i < reference.size() ) {
            findColumn( *++iteratore );  //nome della foreign key

            if ( _it->tipo != reference[i] -> tipo ) {
                cerr << _it->key << " " << reference[i] -> key << ": ";
                throw ForeignTypesError();
            }
            
            _it->reference = reference[i];
            i++;
            
            _reference_tables.push_back( *++iteratore );  //salva TABLE1
            _reference_fields.push_back( *++iteratore );  //salva COLUMN1
        }
    }
}


Table::Table ( const Table& to_copy ) {
    _table_key = to_copy._table_key;
    _fields = to_copy._fields;
    _numrecords = to_copy._numrecords;

    _primary_key = to_copy._primary_key;
    _reference_tables = to_copy._reference_tables;
    _reference_fields = to_copy._reference_fields;

    _it = _fields.begin();
    _List_const_iterator<campo> iter = to_copy._fields.begin();

    while ( _it != _fields.end() ) {
        switch ( _it->tipo ) {
            case INT:
                _it->ptr = (void *) new Column<int> ( *ptr_int(iter -> ptr) );
                break;
            case FLOAT:
                _it->ptr = (void *) new Column<float> ( *ptr_float(iter -> ptr) );
                break;
            case CHAR:
                _it->ptr = (void *) new Column<char> ( *ptr_char(iter -> ptr) );
                break;
            case TEXT:
                _it->ptr = (void *) new Column<string> ( *ptr_text(iter -> ptr) );
                break;
            case DATE:
                _it->ptr = (void *) new Column<Date> ( *ptr_date(iter -> ptr) );
                break;
            case TIME:
                _it->ptr = (void *) new Column<Time> ( *ptr_time(iter -> ptr) );
                break;
        }
        _it++;
        iter++;
    }
}


Table::~Table() {
    clearTable(); //fa la clear delle colonne

    for ( _it=_fields.begin(); _it != _fields.end(); _it++ ) {
        if ( _it->ptr != nullptr)
        switch(_it->tipo) {
            case INT: //elimino memoria allocata con la new
                delete (ptr_int)_it->ptr;
                break;
            case FLOAT:
                delete (ptr_float)_it->ptr;
                break;
            case CHAR:
                delete (ptr_char)_it->ptr;
                break;
            case DATE:
                delete (ptr_date)_it->ptr;
                break;
            case TIME:
                delete (ptr_time)_it->ptr;
                break;
            case TEXT:
                delete (ptr_text)_it->ptr;
                break;
        }
        _it->ptr = nullptr;
        _it->reference = nullptr;
    }

    _fields.clear();
    _reference_fields.clear();
    _reference_tables.clear();
    _primary_key.clear();
}


void Table::readTable( ifstream &f ) {
    int nr=0;
    char c;

    f >> nr;
    _numrecords = nr;
    resizeTable( nr );
    for ( int i=0; i< _numrecords;i++ ) {
        for ( _it = _fields.begin(); _it != _fields.end(); _it++ ) {
            switch (_it->tipo) {
                case INT:
                    f.get(c);
                    if(default_value != f.peek())
                        f >> ptr_int(_it->ptr)->getReferenceToElement(i);
                    else{
                        f.get(c);
                        ptr_int(_it->ptr)->getReferenceToElement(i) = int_default;
                    }
                    break;
                case FLOAT:
                    f.get(c);
                    if(default_value != f.peek())
                        f >> ptr_float(_it->ptr)->getReferenceToElement(i);
                    else{
                        f.get(c);
                        ptr_float(_it->ptr)->getReferenceToElement(i) = float_default;
                    }
                    break;
                case CHAR:
                    f.get( c); // per lo spazio
                    f.get(ptr_char(_it->ptr)->getReferenceToElement(i) );
                    break;
                case DATE:
                    f.get(c);
                    if(default_value != f.peek())
                        f >> ptr_date(_it->ptr)->getReferenceToElement(i);
                    else{
                        f.get(c);
                        ptr_date(_it->ptr)->getReferenceToElement(i) = Date();
                    }
                    break;
                case TIME:
                    f.get(c);
                    if(default_value != f.peek())
                        f >> ptr_time(_it->ptr)->getReferenceToElement(i);
                    else{
                        f.get(c);
                        ptr_time(_it->ptr)->getReferenceToElement(i) = Time();
                    };
                    break;
                case TEXT:
                    f.get(c); //prende lo spazio
                    string str;
                    bool end = false;
                    bool backslash = false;
                    f.get( c ); //prende il "
                    while( !end ) {
                        str.push_back( c );
                        f.get( c );
                        if ( c == '\\' ) {
                            backslash = !backslash;
                        }
                        else if ( c == '\"' && !backslash ) {
                            end = true;
                        }
                        else
                            backslash = false;
                    }
                    str.push_back( c );
                    ptr_text(_it->ptr)->getReferenceToElement(i) = str;
                    break;
            }
        }
    }
}


void Table::writeTable ( ofstream &f ) {
    vector<campo> foreign_keys;
    f << endl << endl << _table_key << " ";

    for ( _it = _fields.begin(); _it != _fields.end() ; _it++ ) {
        f << _it->key << " " << convertTypeToString( _it->tipo ) << " ";
        if( _it->is_not_null )
            f << "NOT_NULL" << " ";
        if( _it->tipo == INT && _it->is_auto  ) {
            f << "AUTO_INCREMENT" << " ";
            f << _it->auto_increment << " ";
        }
        if( _it->reference != nullptr )
            foreign_keys.push_back( *_it );
    }

    f << "PRIMARY " << _primary_key << " ";

    if ( !foreign_keys.empty() ) {
        f << "FOREIGN ";
        for( int i=0; i<foreign_keys.size(); i++ )
            f << foreign_keys[i].key << " " << _reference_tables[i] << " " << _reference_fields[i] << " ";
    }

    f << "*" << endl;
    f << _numrecords;

    for ( int i=0; i<_numrecords; i++ ) {
        f << endl;
        for ( _it = _fields.begin(); _it != _fields.end(); _it++ ) {
            switch ( _it->tipo ) {
                case INT:
                    if(ptr_int( _it->ptr ) -> getElement(i) != int_default)
                        f << ptr_int( _it->ptr ) -> getElement(i);
                    else
                        f << default_value;
                    break;
                case FLOAT:
                    if(ptr_float( _it->ptr ) -> getElement(i) != float_default)
                        f << ptr_float( _it->ptr ) -> getElement(i);
                    else
                        f << default_value;
                    break;
                case CHAR:
                    f << ptr_char( _it->ptr ) -> getElement(i);
                    break;
                case DATE:
                    if(ptr_date( _it->ptr ) -> getElement(i) != Date())
                        f << ptr_date( _it->ptr ) -> getElement(i);
                    else
                        f << default_value;
                    break;
                case TIME:
                    if(ptr_time( _it->ptr ) -> getElement(i) != Time())
                        f << ptr_time( _it->ptr ) -> getElement(i);
                    else
                        f << default_value;
                    break;
                case TEXT:
                    f << ptr_text ( _it->ptr ) -> getElement(i);
                    break;
            }
            if ( _it != --_fields.end() )
                f << " ";
        }
    }
}


string Table::getKey() const {
    return _table_key;
}


const campo& Table::findColumn( const string& name ) {
    for ( _it = _fields.begin(); _it != _fields.end(); _it++ ) {
        if ( _it->key == name )
            return *_it;
    }
    cerr << name << ": ";
    throw NotFoundColumn();
}


campo* Table::getFieldPointer( const string& name ) {
    findColumn( name );
    return &(*_it);
}


void Table::addRecord( list<string>& record_info ) {  // record_info è LISTA_COLONNE VALUES LISTA_VALORI
    list<string>::iterator it_values = record_info.begin();
    vector<string> column_keys;
    vector<string> value_to_add;
    vector<string> types;

    while ((*it_values) != "VALUES") {                  //salva i nomi delle colonne
        column_keys.push_back( *it_values );
        it_values++;
    }
    for (int i = 0; i < column_keys.size(); i++) {
        types.push_back( *++it_values );                //salva i tipi dei valori
        value_to_add.push_back( *++it_values );         //salva i valori
    }

    vector<string>::iterator i;
    vector<campo*> fields_in_list( column_keys.size() );
    vector<campo*> fields_not_in_list;

    /* Verifico che:
       il formato dei valori letti sia corretto
       tutti i campi not null siano in column_keys
       per le foreign: il valore da aggiungere è nel campo di riferimento
       per la primary: il valore da aggiungere non è presente nella colonna

     Creo due liste separate di puntatori ai campi: una per i campi a cui devo aggiungere il valore inserito dall'utente,
     una per quelli a cui devo aggiungere il default value
    */

    for ( _it = _fields.begin(); _it != _fields.end(); _it++ ) {
        i = find( column_keys.begin(), column_keys.end(), _it->key );
        int n = i - column_keys.begin();

        if ( i != column_keys.end() ) {  //il campo è in column_keys
            type tipo = convertStringToType( types[n] );
            if ( _it->tipo != tipo && !(_it->tipo == FLOAT && tipo == INT) ) {
                cerr << _it->key << " " << value_to_add[n] << ": ";
                throw NotAcceptableData();
            }

            if ( _it->reference != nullptr )
                if (!foundInColumn(*(_it->reference), value_to_add[n])) {
                    cerr << _it->key << " " << value_to_add[n] << ": ";
                    throw NotInReference();
                }

            if (_it->key == _primary_key)
                if (foundInColumn(*_it, value_to_add[n]))
                {   cerr << value_to_add[n] << ": ";
                    throw NotUniqueValue();
                }

            fields_in_list[n] = &*_it;
        }
        else {  //il campo non è in column keys
            if ( (_it->is_not_null || _it->key == _primary_key) && !_it->is_auto ) {
                cerr << _it->key << ": ";
                throw NotNullException();
            }

            int j = 0;
            while ( _it->key == _primary_key && _it->is_auto && foundInColumn(*_it, to_string(_it-> auto_increment)) ){
                _it-> auto_increment++;
                j--;
            }

            if ( _it->reference != nullptr && _it->is_auto && !foundInColumn(*(_it->reference),to_string(_it->auto_increment)) ) {
                cerr << _it->key << " " << _it->auto_increment << ": ";
                throw NotInReference();
            }else if ( j<0 )
                cout << "Attenzione la primary key ( " << _it->key << " ) è anche AUTO_INCREMENT" << endl << "Al fine di non avere valori uguali ho incrementato da " << _it->auto_increment + j - 1 << " fino a " << _it->auto_increment << endl;

            fields_not_in_list.push_back( &*_it );
        }
    }

    if(fields_in_list.size() + fields_not_in_list.size() != _fields.size())
        throw NotFoundColumn();

    for ( int j = 0; j < fields_in_list.size(); j++ )
        switch ( fields_in_list[j] -> tipo ) {
            case INT:
                ptr_int( fields_in_list[j]->ptr ) -> addElementFromString( value_to_add[j] );
                if ( fields_in_list[j] -> is_auto )
                    fields_in_list[j] -> auto_increment = 1 + ptr_int(fields_in_list[j]->ptr) -> readElement(value_to_add[j]);
                break;
            case FLOAT:
                ptr_float( fields_in_list[j]->ptr ) -> addElementFromString( value_to_add[j] );
                break;
            case CHAR:
                ptr_char( fields_in_list[j]->ptr ) -> addElement( value_to_add[j].front() );
                break;
            case TIME:
                ptr_time( fields_in_list[j]->ptr ) -> addElementFromString( value_to_add[j] );
                break;
            case DATE:
                ptr_date( fields_in_list[j]->ptr ) -> addElementFromString( value_to_add[j] );
                break;
            case TEXT:
                ptr_text( fields_in_list[j]->ptr ) -> addElement( value_to_add[j] );
                break;
            default:
                break;
        }

    for ( int j = 0; j < fields_not_in_list.size(); j++ )
        switch ( fields_not_in_list[j] -> tipo ) {
            case INT:
                if ( fields_not_in_list[j] -> is_auto ) {
                    ptr_int( fields_not_in_list[j]->ptr ) -> addElement( fields_not_in_list[j] -> auto_increment );
                    fields_not_in_list[j]->auto_increment++;
                } else
                    ptr_int( fields_not_in_list[j]->ptr ) -> addElement( int_default );
                break;
            case FLOAT:
                ptr_float( fields_not_in_list[j]->ptr ) -> addElement( float_default );
                break;
            case CHAR:
                ptr_char( fields_not_in_list[j]->ptr) -> addElement( char_default );
                break;
            case TIME:
                ptr_time( fields_not_in_list[j]->ptr ) -> addElement( time_default );
                break;
            case DATE:
                ptr_date( fields_not_in_list[j]->ptr ) -> addElement( date_default );
                break;
            case TEXT:
                ptr_text( fields_not_in_list[j]->ptr ) -> addElement( text_default );
                break;
            default:
                break;
        }
    _numrecords++;
}

                                                  // la lista è del tipo "AGE SALARY .... WHERE age = 20 ORDER NAME DESC"
void Table::select( list<string>& my_list ) {     // oppure "* AGE = 20"
    list<string>::iterator iter;                  // oppure solo "*"
    string column_key, direction_order;
    bool ord = false;

    iter = my_list.end();
    iter--;

    if( *iter=="ASC" || *iter== "DESC" ){
        iter--;
        iter--;
        ord = true;
        iter = my_list.erase(iter );
        column_key = *iter;     //salvo il nome della colonna in base alla quale devo ordinare la stampa
        iter = my_list.erase(iter );
        direction_order = *iter;
        iter = my_list.erase(iter );
    }

    iter = my_list.begin();

    list<campo> column_to_select;               //salvo campi da stampare

    bool end = false;

    //my_list è:
    // * WHERE  oppure  CAMPI WHERE
    // * oppure CAMPI

    if ( *iter != "*" ) {
        while (iter != my_list.end() && !end)
            if ( *iter != "WHERE" ) {                   //vado avanti fino a che incontro WHERE
                column_to_select.push_back( findColumn(*iter) );
                iter++;
            }
            else end = true;
    }
    else  {
        column_to_select = _fields;
        iter++;
    }

    // * WHERE  oppure  CAMPI WHERE  --> iter è su WHERE
    // * oppure CAMPI                --> iter è my_list.end()

    vector<int> records_selected;
    if (iter == my_list.end() ) {             //se non deve essere effettuata una selezione, allora records_selected deve essere un vettore contenente tutti i numeri da 0 a _numrecords-1
        records_selected.resize(_numrecords);
        for ( int i=0; i<_numrecords; i++)
            records_selected[i] = i ;
    }
    else {
        my_list.erase(my_list.begin(), ++iter );                //elimino fino a WHERE (compreso)
                                                                //my_list è CAMPO OPERATORE ELEMENT oppure CAMPO BETWEEN ELEM1 ELEM2
        selectIndex(my_list, records_selected );         //selezione record tramite confronto
    }

    if ( ord == true ) {
        orderRecord(records_selected, column_key, direction_order);
    }

    string r_a = r_arrow;

    cout << setw(r_a.size()) << " " <<"***  " << _table_key << "   ***" << endl;

    bool name_n = true;
    list <string::iterator> name_it;
    list <string::iterator>::iterator n_it;
    for (_it = column_to_select.begin(); _it != column_to_select.end(); _it++)  //mi salvo il puntatore all'inizio del nome delle colonne
        name_it.push_back(_it->key.begin());

    do{                 //stampo i nomi delle colonne
        cout << setw(r_a.size()) << " ";
        name_n = false;
        n_it = name_it.begin();
        for (_it = column_to_select.begin(); _it != column_to_select.end(); _it++) {
            if(**n_it == '\000'){
                if ( _it->tipo != TEXT )
                    cout << setw(column_width-1) << " ";
                else
                    cout << setw(column_width_text-1) << " ";
            }else if ( _it->tipo != TEXT ) {
                for (int i = 0; i < column_width-1; i++) {
                    if (**n_it != '\000') {
                        cout << **n_it;
                        (*n_it)++;
                    } else {
                        cout << setw(column_width-i-1) << " ";
                        i=column_width;
                    }
                }
            }else{
                for (int i = 0; i < column_width_text-1; i++) {
                    if (**n_it != '\000') {
                        cout << **n_it;
                        (*n_it)++;
                    } else {
                        cout << setw(column_width_text-i-1) << " ";
                        i=column_width_text;
                    }
                }
            }
            cout << " ";
            if(**n_it != '\000')
                name_n = true;
            n_it++;
        }
        cout << endl;
    }while( name_n );

    cout << endl;

    for ( int elem : records_selected ) {
        list <string::iterator> string_it;
        list <string::iterator>::iterator str_it;
        vector <int> ncolumn(1,0);
        int ncol = 0;
        bool text_n = false;

        cout << r_a;

        for (_it = column_to_select.begin(); _it != column_to_select.end(); _it++) {
            ncol++;
            switch (_it->tipo) {
                case INT:
                    if (((ptr_int) _it->ptr) -> getElement( elem ) != int_default )
                        cout << setw( column_width ) << left << ( (ptr_int) _it->ptr ) -> getElement( elem );
                    else
                        cout << setw( column_width ) << left << " ";
                    break;
                case FLOAT:
                    if (((ptr_float) _it->ptr)->getElement( elem ) != float_default)
                        cout << setw( column_width ) << left << ( (ptr_float) _it->ptr ) -> getElement( elem );
                    else
                        cout << setw( column_width ) << left << " ";
                    break;
                case CHAR:
                    if (((ptr_char) _it->ptr ) -> getElement( elem ) == '\n')
                        cout << setw( column_width ) << left << "\\n";
                    else if (((ptr_char) _it->ptr ) -> getElement( elem ) == '\t')
                        cout << setw( column_width ) << left << "\\t";
                    else
                        cout << setw( column_width ) << left << ( (ptr_char) _it->ptr ) -> getElement( elem );
                    break;
                case DATE:
                    if( ((ptr_date) _it->ptr) -> getElement( elem ) != Date())
                        cout << setw( column_width ) << left << ( (ptr_date) _it->ptr ) -> getElement( elem );
                    else
                        cout << setw( column_width ) << left << " ";
                    break;
                case TIME:
                    if( ((ptr_time) _it->ptr) -> getElement( elem ) != Time())
                        cout << setw( column_width ) << left << ((ptr_time) _it->ptr)->getElement( elem );
                    else
                        cout << setw( column_width ) << left << " ";
                    break;
                case TEXT:
                    string_it.push_back (((ptr_text) _it->ptr)->getReferenceToElement(elem).begin() + 1);
                    str_it = string_it.end();
                    str_it--;

                    ncolumn.push_back( ncol );
                    printText(elem, str_it, ncolumn, ncol );
                    if(**str_it != '\000')
                        text_n = true;
            }
        }

        ncol=0;
        cout << endl;

        while ( text_n ) {
            str_it = string_it.begin();
            text_n = false;

            cout << setw(r_a.size()) << " ";

            for ( ncol=-1; ncol > -(ncolumn.size()); ncol--) {
                printText(elem, str_it, ncolumn, ncol );
                if(**str_it != '\000' )
                    text_n = true;
                if( ncol != 1 - (ncolumn.size()) )
                    str_it++;
            }
            cout << endl;
        }
    }
    cout << endl;
}


void Table::printText (const int& n, list<string::iterator>::iterator str_it, const vector<int>& ncolumn, const int& ncol ) {
    if ( ncol<0 ) {
        for ( int i=0; i < ( (ncolumn[-ncol]) - (ncolumn[-ncol-1]) ) -1; i++ )
            cout << setw( column_width ) << " ";
    }

    if(**str_it != '\000' ) {

        int j = 0;
        string::iterator Beta_it = *str_it;
        for( int i=0; i < (column_width_text-1); i++ ) {
            if ( *Beta_it == ' ') {
                cout << *Beta_it;
                j++;
                Beta_it++;
                *str_it = Beta_it;
            } else if ( *Beta_it == '\t' ) {
                int mt = 4 - (i-( (i/4)*4 ));
                for ( int m=0; m < mt; m++ ) {
                    if(i < (column_width_text-1)){
                        cout << " ";
                        j++;
                        i++;
                    }
                }
                i--;
                Beta_it++;
                *str_it = Beta_it;
            } else {
                for ( int k=0; k < (column_width_text-1-i); k++) {
                    if ( (*(Beta_it+1)=='"' || *(Beta_it+1)=='\\') && *Beta_it=='\\' ) {
                        Beta_it++;
                    }

                    Beta_it++;

                    if ( *Beta_it=='\000' )
                        i = column_width_text;
                    else if ( *Beta_it==' ' || *Beta_it=='\n' || *Beta_it=='\t' || *(Beta_it+1)=='\000' ) {
                        i += k;
                        for ( int h=0; h<k+1; h++ ) {
                            j++;
                            if ((*(*str_it + 1) == '"' || *(*str_it + 1) == '\\') && **str_it == '\\' )
                                ( *str_it )++;
                            cout << **str_it;
                            ( *str_it )++;
                        }

                        if(*(Beta_it+1)=='\000'){
                            Beta_it++;
                            i = column_width_text;
                        }

                        if( *Beta_it=='\n' ){
                            i = column_width_text;
                            ( *str_it )++;
                        }
                        k = column_width_text;
                    }

                    if(i == column_width_text-2-k)
                        i = column_width_text;
                }
            }
        }

        if ( j!=0 )
            cout << setw( column_width_text-j ) << " ";
        else if ( *Beta_it!='\000' ) {
            for ( int i=0; i<column_width_text-1; i++ ) {
                cout << **str_it;
                ( *str_it )++;
            }
            cout << " ";
        }
        if( *Beta_it=='\000' ){
            *str_it = Beta_it;
            if(j==0)
                cout << setw(column_width_text) << " ";
        }

    }
    else {
        cout << setw( column_width_text ) << " ";
    }
}


int Table::deleteFrom( list<string>& my_string ) {
    vector<int> index_to_delete;

    selectIndex( my_string, index_to_delete );  //modifica index_to_delete inserendo gli indici dei record da eliminare
    deleteRecords(index_to_delete);

    return index_to_delete.size();
}


int Table::update( list<string> &my_string ) {       //prende una lista COLUMN TYPE VALUE (in numero variabile)  WHERE COLUMN_TO_FIND OPERATOR VALUE
                                                     //oppure           COLUMN TYPE VALUE (in numero variabile)  WHERE COLUMN_TO_FIND OPERATOR BETWEEN ELEM1 ELEM2
    list<string>::iterator iter= my_string.begin();
    vector<campo*> column_to_set;
    vector<string> value_to_set;

    /* salvo i campi da aggiornare e controllo che il formato dei dati sia corretto
       Se tra i campi da aggiornare c'è un auto increment, lancio un'eccezione
       Se il campo da aggiornare è una foreign key, controllo che il valore da aggiungere sia presente nella colonna di riferimento
       Se è una primary key, controllo che non sia presente nella colonna
       */
    while ( *iter != "WHERE" ) {
        campo* field = getFieldPointer(*iter);

        if (field->is_auto)
        throw AutoIncrementException();

        type tipo = convertStringToType(*++iter);
        if ( tipo != field->tipo  && !(field->tipo==FLOAT && tipo==INT ) ) {
            cerr << field->key << " " << *iter << ": ";
            throw NotAcceptableData();
        }

        iter++;

        if ( field->reference != nullptr )
            if ( !foundInColumn(*field->reference, *iter) ) {
                cerr << field->key << " " << *iter << ": ";
                throw NotInReference();
            }

        if ( field->key == _primary_key )
            if ( foundInColumn(*field, *iter) ) {
                cerr << *iter <<": ";
                throw NotUniqueValue();
            }
        value_to_set.push_back(*iter);
        column_to_set.push_back(field);

        iter++;
    }

    my_string.erase( my_string.begin(),++iter );        //my string è COLUMN_TO_FIND OPERATOR VALUE oppure COLUMN_TO_FIND OPERATOR BETWEEN ELEM1 ELEM2

    vector<int> index_to_set;
    selectIndex( my_string, index_to_set );
    for(int i=0; i< column_to_set.size(); i++){

        if ( column_to_set[i]->key == _primary_key ) {
            if ( index_to_set.size() > 1 ) {         //lancio un'eccezione, perchè non posso assegnare lo stesso valore a più elementi della primary key
                cerr << value_to_set[i] << ": ";
                throw NotUniqueValue();
            }
        }
    }

    void* p;

    for ( int i=0; i< column_to_set.size(); i++ ) {
        p = column_to_set[i]->ptr;
        switch ( column_to_set[i]->tipo ) {
            case INT:
                ptr_int(p)->updateElements(index_to_set, ptr_int(p)->readElement(value_to_set[i]));
                break;
            case FLOAT:
                ptr_float(p)->updateElements(index_to_set, ptr_float(p)->readElement(value_to_set[i]));
                break;
            case CHAR:
                ptr_char(p)->updateElements(index_to_set, value_to_set[i].front());
                break;
            case DATE:
                ptr_date(p)->updateElements(index_to_set, ptr_date(p)->readElement(value_to_set[i]));
                break;
            case TIME:
                ptr_time(p)->updateElements(index_to_set, ptr_time(p)->readElement(value_to_set[i]));
                break;
            case TEXT:
                ptr_text(p)->updateElements(index_to_set, value_to_set[i]);
        }
    }

    return index_to_set.size();
}


void Table::selectIndex(list<string>& my_list, vector<int>& index ) { //my_list è del tipo: SALARY FLOAT BETWEEN 11.1 12.2 oppure SALARY FLOAT > 11.1
    list<string>::iterator iteratore = my_list.begin();
    string column_key = *iteratore;

    campo field = findColumn( column_key );
    vector<string> val;  //conterrà 1 elemento per tutti gli operatori, 2 elementi nel caso dell'operatore BETWEEN
    string operatore;
    void *p = _it->ptr;   //puntatore alla colonna su cui devo fare la selezione degli indici

    if ( *++iteratore != "UNKNOWN" ) {
        type tipo = convertStringToType( *iteratore );
        if ( field.tipo != tipo && !(field.tipo == FLOAT && tipo == INT) ) {
            cerr << column_key << " " << *iteratore << ": ";
            throw NotAcceptableData();
        }
        operatore = *++iteratore;

        vector<char> caratteri;

        val.push_back( *++iteratore );

        if (++iteratore != my_list.end() ) {
            val.push_back(*iteratore);
        }

        switch ( field.tipo ) {
            case INT:
                index = ptr_int(p) -> findElements(operatore, ptr_int(p) -> readElements( val ));
                break;
            case FLOAT:
                index = ptr_float(p) -> findElements(operatore, ptr_float(p) -> readElements( val ));
                break;
            case CHAR:
                //l'operatore >> non leggerebbe \n, \t e spazio, quindi passo un vettore di caratteri
                for(int i=0;i<val.size();i++)
                caratteri.push_back(val[i].front());
                index = ptr_char(p) -> findElements(operatore, caratteri);
                break;
            case DATE:
                index = ptr_date(p) -> findElements(operatore, ptr_date(p) -> readElements( val ));
                break;
            case TIME:
                index = ptr_time(p) -> findElements(operatore, ptr_time(p) -> readElements( val ));
                break;
            case TEXT:
                index = ptr_text(p) -> findElements(operatore, val);
        }
    } else {  // l'utente ha scritto WHERE CAMPO = DEFAULT
        switch ( field.tipo ) {
            case INT:
                index = ptr_int(p) -> findElementsEqualTo(int_default);
                break;
            case FLOAT:
                index = ptr_float(p) -> findElementsEqualTo(float_default);
                break;
            case CHAR:
                index = ptr_char(p) -> findElementsEqualTo(char_default);
                break;
            case DATE:
                index = ptr_date(p) -> findElementsEqualTo(date_default);
                break;
            case TIME:
                index = ptr_time(p) -> findElementsEqualTo(time_default);
                break;
            case TEXT:
                index = ptr_text(p) -> findElementsEqualTo(text_default);
        }
    }
}


bool Table::foundInColumn ( const campo &field, const string &value ) {
    bool found = false;

    switch ( field.tipo ) {
        case INT:
            found = ptr_int(field.ptr)->isInColumn(    ptr_int(field.ptr)->readElement(value)     );
            break;
        case FLOAT:
            found = ptr_float(field.ptr)->isInColumn(   ptr_float(field.ptr)->readElement(value)   );
            break;
        case CHAR:
            found = ptr_char(field.ptr)->isInColumn(  value.front()   );
            break;
        case TIME:
            found = ptr_time(field.ptr)->isInColumn(  ptr_time(field.ptr)->readElement(value)  );
            break;
        case DATE:
            found = ptr_date(field.ptr)->isInColumn(  ptr_date(field.ptr)->readElement(value)   );
            break;
        case TEXT:
            found = ptr_text(field.ptr)->isInColumn(value);
            break;
        default:
            break;
    }
    return found;
}


void Table::checkReference( const string &nome ) {
    int i = 0;
    _it = _fields.begin();
    char c,answer;
    bool end = false;
    
    while ( i < _reference_tables.size() && _it != _fields.end() ) {
        if( _it->reference != nullptr ) {
            if ( _reference_tables[i] == nome ) {
                end = false;
                while ( !end ) {
                    cout << "Il campo " << _it->key << " della tabella " << _table_key
                    << " è collegato alla tabella " << nome << endl;
                    cout << "Continuare? y/n ";
                    cin >> answer;
                    cin.get(c);
                    if ( c != '\n' ) {
                        answer = ' ';
                        do { cin.get(c); }
                        while ( c != '\n' );
                    }
                    if ( answer == 'n' || answer == 'N' ){
                        _to_be_canceled.clear();
                        _to_be_set_to_null.clear();
                        throw NotDrop();
                    }
                    else if ( answer == 'y' || answer == 'Y' )
                        end = true;
                    else cout << "Opzione non accettabile" << endl << endl;
                }
                //salvo gli indici che devono essere cancellati in _reference_tables e reference_fields, se la cancellazione verrà confermata
                _to_be_canceled.push_back( i );
                //salvo i puntatori ai campi di cui dovrò mettere a null il puntatore reference
                _to_be_set_to_null.push_back( &*_it );
            }
            i++;
        }
        _it++;
    }
}


void Table::setReferencePointersToNull ( const string &nome ) {
    for (int i = _to_be_canceled.size() - 1 ; i >= 0; i-- ) {
        _reference_tables.erase( _reference_tables.begin() + _to_be_canceled[i] );
        _reference_fields.erase( _reference_fields.begin() + _to_be_canceled[i] );
    }

    for ( vector<campo*>::iterator i = _to_be_set_to_null.begin(); i != _to_be_set_to_null.end(); i++ )
        (*i)->reference = nullptr;

    _to_be_canceled.clear();
    _to_be_set_to_null.clear();
}


void Table::deleteRecords (vector<int> index){
    for ( _it = _fields.begin(); _it != _fields.end(); _it++ ) {
        switch ( _it->tipo ) {
            case INT:
                ptr_int(_it->ptr) -> deleteElements(index);
                break;
            case FLOAT:
                ptr_float(_it->ptr) -> deleteElements(index);
                break;
            case CHAR:
                ptr_char(_it->ptr) -> deleteElements(index);
                break;
            case DATE:
                ptr_date(_it->ptr) -> deleteElements(index);
                break;
            case TIME:
                ptr_time(_it->ptr) -> deleteElements(index);
                break;
            case TEXT:
                ptr_text(_it->ptr) -> deleteElements(index);
                break;
        }
    }
    _numrecords = _numrecords-index.size();
}


void Table::resizeTable ( const int &n ) {
    for ( _it = _fields.begin(); _it != _fields.end(); _it++ ) {
        switch (_it->tipo) {
            case INT:
                ptr_int(_it->ptr) -> resize(n);
                break;
            case FLOAT:
                ptr_float(_it->ptr) -> resize(n);
                break;
            case CHAR:
                ptr_char(_it->ptr) -> resize(n);
                break;
            case DATE:
                ptr_date(_it->ptr) -> resize(n);
                break;
            case TIME:
                ptr_time(_it->ptr) -> resize(n);
                break;
            case TEXT:
                ptr_text(_it->ptr) -> resize(n);
                break;

        }
    }
}


void Table::clearTable() {
    for ( _it = _fields.begin(); _it != _fields.end(); _it++ ) {
        switch ( _it->tipo ) {
            case INT:
                ptr_int(_it->ptr) -> clearColumn();
                break;
            case FLOAT:
                ptr_float(_it->ptr) -> clearColumn();
                break;
            case CHAR:
                ptr_char(_it->ptr) -> clearColumn();
                break;
            case DATE:
                ptr_date(_it->ptr) -> clearColumn();
                break;
            case TIME:
                ptr_time(_it->ptr) -> clearColumn();
                break;
            case TEXT:
                ptr_text(_it->ptr) -> clearColumn();
                break;
        }
    }
    _numrecords = 0;
}


void Table::orderRecord (vector<int> &records_selected, string &column, string &order ) {

    campo field = findColumn ( column );  // cerco il campo in base al quale verrà ordinata la stampa

    // salvo nel vettore gli indici dei records_selected disposti nell'ordine in base al quale devono essere stampati
    switch ( field.tipo ) {
        case INT:
            records_selected = ( (ptr_int)(_it->ptr) ) -> orderElements (records_selected, order);
            break;
        case FLOAT:
            records_selected = ( (ptr_float)(_it->ptr) ) -> orderElements (records_selected, order);
            break;
        case CHAR:
            records_selected = ( (ptr_char)(_it->ptr) ) -> orderElements (records_selected, order);
            break;
        case DATE:
            records_selected = ( (ptr_date)(_it->ptr) ) -> orderElements (records_selected, order);
            break;
        case TIME:
            records_selected = ( (ptr_time)(_it->ptr) ) -> orderElements (records_selected, order);
            break;
        case TEXT:
            records_selected = ( (ptr_text)(_it->ptr) ) -> orderElements (records_selected, order);
    }
}


type Table::convertStringToType ( const string& tipo ) const {
    if ( tipo == "INT" )
        return INT;
    else if ( tipo == "FLOAT" )
        return FLOAT;
    else if ( tipo == "CHAR" )
        return CHAR;
    else if ( tipo == "DATE" )
        return DATE;
    else if ( tipo == "TEXT" )
        return TEXT;
    else if ( tipo == "TIME" )
        return TIME;
    return NOT_IDENTIFIED;
}


string Table::convertTypeToString ( const type& tipo ) const {
    switch ( tipo ) {
        case INT:
            return "INT";
        case FLOAT:
            return "FLOAT";
        case CHAR:
            return "CHAR";
        case DATE:
            return "DATE";
        case TIME:
            return "TIME";
        case TEXT:
            return "TEXT";
    }
    return "NOT_IDENTIFIED";
}