//
// Created by Avalle Dario, De Carlo Francesca, Fagnani Pietro
//

#ifndef PROGETTO_TABLE_H
#define PROGETTO_TABLE_H


#include <list>
#include "Eccezioni.h"
#include "Column.hpp"


typedef struct campo {
    string key;                         //il nome della colonna
    type tipo;                          //il tipo della colonna
    bool is_not_null = false;
    bool is_auto = false;
    int auto_increment = 0;             //il prossimo valore da aggiungere
    void* ptr = nullptr;                //puntatore alla colonna
    campo* reference = nullptr;         //puntatore al campo a cui fa rifermento per la FOREIGN
} campo;


class Table {
public:
    Table( list<string>& column_info, const vector<campo*>& reference );
    Table( const Table& to_copy );
    ~Table();
    void readTable( ifstream &f );
    void writeTable( ofstream &f );

    string getKey() const;

    const campo& findColumn( const string& name );
    campo* getFieldPointer(const string& name );

    void addRecord( list<string>& record_info );
    void select( list<string>& my_list );
    void printText(const int& n, list<string::iterator>::iterator str_it, const vector<int>& ncolumn, const int& ncol );
    int deleteFrom( list<string>& my_string );
    int update( list<string> &my_string );
    void orderRecord(vector<int> &records_selected, string &column, string &order );

    //prende CAMPO OPERATORE ELEMENTO oppure CAMPO BETWEEN elemento 1 elemento 2
    // e mette nel vettore gli indici dei record per cui vale quella condizione
    void selectIndex(list<string> & my_list, vector<int>& index );

    bool operator== ( const string& nome ) {
        return ( this -> _table_key == nome );
    }

    bool foundInColumn( const campo& field, const string& value );

    //Viene chiamata quando è richiesta la cancellazione di una tabella:
    // se trova il suo nome nelle reference_tables, chiede all'utente se vuole confermare l'eliminazione.
    // Salva le informazioni che servono per eliminare i collegamenti, nel caso in cui l'eliminazione venga poi confermata
    void checkReference( const string& nome );


    // mette a nullptr il puntatore del campo che fa riferimento alla tabella da eliminare
    void setReferencePointersToNull( const string& nome );

    void deleteRecords(vector<int> index);
    void resizeTable( const int& n );
    void clearTable();

    type convertStringToType(const string& tipo ) const;
    string convertTypeToString(const type& tipo ) const;

    string _primary_key;

private:
    string _table_key;
    list<campo> _fields;
    list<campo>::iterator _it;
    int _numrecords;


    //per ogni foreign key, le liste contengono:
    // - nome del campo collegato
    // - nome  della tabella in cui si trova
    // L'ordine è lo stesso che le foreign keys hanno nella lista fields
    vector<string> _reference_tables;
    vector<string> _reference_fields;

    vector<int> _to_be_canceled;
    vector<campo*> _to_be_set_to_null;
};

typedef Column<int> *ptr_int;
typedef Column<float> *ptr_float;
typedef Column<char> *ptr_char;
typedef Column<Time> *ptr_time;
typedef Column<Date> *ptr_date;
typedef Column<string> *ptr_text;

#endif //PROGETTO_TABLE_H