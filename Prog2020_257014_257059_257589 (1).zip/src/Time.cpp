//
// Created by Avalle Dario, De Carlo Francesca, Fagnani Pietro
//

#include "Time.h"

Time::Time() {
    this -> _hour = 25;
    this -> _min = 0;
    this -> _sec = 0;
}


Time::Time( const int &h, const int &m, const int &s ) {
    this -> _hour = h;
    this -> _min = m;
    this -> _sec = s;
}


string Time::str() const {
    ostringstream stream;

    stream << setfill('0') << setw(2) << this->_hour << ":" ;
    stream << setfill('0') << setw(2) << this->_min << ":" ;
    stream <<  setfill('0') << setw(2) << this->_sec;
    return stream.str();
}


bool Time::operator==(const Time &to_compare) const {
    return ((this->_sec == to_compare._sec) &&
            (this->_min == to_compare._min) &&
            (this->_hour == to_compare._hour));
}


bool Time::operator!=(const Time &to_compare) const {
    return !(*this == to_compare);
}


bool Time::operator>(const Time & to_compare) const{
    return ( (*this).str() > to_compare.str());
}


bool Time::operator<(const Time & to_compare) const{
    return ((*this).str() < to_compare.str());
}


ostream& operator<< (std::ostream& stream, const Time& d) {
    stream << d.str();
    return  stream;
}


istream& operator>> (std::istream& stream, Time &t){
    char c;
    int hourx, minx, secx;
    stream >> hourx >> c >> minx >> c >> secx;
    t = Time(hourx, minx, secx);
    return  stream;
}