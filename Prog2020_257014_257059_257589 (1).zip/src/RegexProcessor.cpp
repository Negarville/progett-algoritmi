//
// Created by Avalle Dario, De Carlo Francesca, Fagnani Pietro
//

#include "RegexProcessor.h"

list<string> RegexProcessor::stringSplit (const string& input_string, const char& splitting_char) {
    list<string> output;
    if ( splitting_char == '"' || splitting_char == '\'' ){
        throw StringSplitError();
    }
    string single_string;
    bool text_flag = false;             //true se siamo all'interno di un testo
    bool char_flag = false;             //true se siamo all'interno di un char
    bool backslash_flag = false;        //true se i caratteri precedenti sono un numero dispari di backslash

    for (char c : input_string) {       //il controllo viene eseguito carattere per carattere
        if ( c == '"' && !backslash_flag && !char_flag ) {
            text_flag = !text_flag;
        }
        if ( c == '\'' && !backslash_flag && !text_flag ) {
            char_flag = !char_flag;
        }
        if ( text_flag ) {
            if ( c == '\\' ) {
                backslash_flag = !backslash_flag;
            }
            else backslash_flag = false;
        }

        //la singola stringa viene inserita nella lista di output quando trova l'ultimo carattere fuori da testi e char
        if ( c == splitting_char && !char_flag && !text_flag ) {
            output.push_back( single_string );
            single_string.clear();
        }
        else single_string.push_back( c );
    }
    if ( !single_string.empty() ) {
        output.push_back( single_string );    //se la singola stringa non e' vuota, va salvata
    }

    return output;
}

//dato un valore, ritorna una lista con all'interno il tipo di dato e il suo valore
list<string> RegexProcessor::valueIdentifier (const string& input) {
    list<string> output;
    smatch match_result;
    if ( regex_search(input, match_result, _type_integer_rgx) ) {           //se matcha con il tipo intero
        output.emplace_back( "INT" );
        stoi( match_result[1] );                                            //serve come controllo per l'overflow
    }
    else if ( regex_search(input, match_result, _type_float_rgx) ) {        //se matcha con il tipo float
        output.emplace_back( "FLOAT" );
        stof( match_result[1] );                                            //serve come controllo
    }
    else if ( regex_search(input, match_result, _type_date_matching_rgx) ) {    //se matcha...
        output.emplace_back( "DATE" );
        int day = stoi( match_result.str(2) );
        int month = stoi( match_result.str(3) );
        int year = stoi( match_result.str(4) );
        bool bissextile = false;
        if ( ((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0) ) {    //calcolo anno bisestile
            bissextile = true;
        }
        if ( (month == 4 || month == 6 || month == 9 || month == 11) && day > 30 ) {
            throw DateSyntaxError();
        }

        else if ( month == 2 && day > 28) {
            if ( !bissextile || day != 29 ) {
                throw DateSyntaxError();
            }
        }
    }
    else if ( regex_search(input, match_result, _type_time_rgx) ) {
        output.emplace_back( "TIME" );
    }
    else if ( regex_search(input, match_result, _type_char_rgx) ) {
        output.emplace_back( "CHAR" );
    }
    else if ( regex_search(input, match_result, _type_text_matching_rgx) ) {
        output.emplace_back( "TEXT" );
        if ( input!=match_result[0] ) {         //controllo che oltre al match non ci siano altri caratteri
            throw ValueSyntaxError();           //ad esempio ALFA"bravo"CHARLIE dà errore
        }
    }
    else if ( regex_search(input, _default_rgx) ) {
        output.emplace_back( "UNKNOWN" );
    }
    else {
        throw ValueSyntaxError();                                             //lancia un'eccezione se il tipo di dato non e' uno di quelli stabiliti
    }

    if ( output.front() == "CHAR" ) {               //il char e' nel formato 'c'; voglio eliminare i singoli apici
        string my_char = match_result[1];
        my_char.pop_back();
        my_char.erase(0,1);
        output.push_back( my_char );
    }
    else if ( output.front() == "UNKNOWN" ) {
        output.emplace_back( "DEFAULT" );
    }
    else {
        output.push_back(match_result[1]);
    }
    return output;
}

//prende l'input da tastiera e riconosce quale query l'utente vuole lanciare
RegexOutput RegexProcessor::functionIdentifier ( const string& input ) {
    RegexOutput output;
    if ( regex_search(input, _create_table_rgx) ) {
        output.my_command = CREATE;
        output.organized_input = createTable ( input );
    }
    else if ( regex_match(input, _drop_table_rgx) ) {
        output.my_command = DROP;
        output.organized_input = dropTable ( input );
    }
    else if ( regex_match(input, _insert_into_rgx) ) {
        output.my_command = INSERT;
        output.organized_input = insertInto ( input );
    }
    else if ( regex_match(input, _delete_from_rgx) ) {
        output.my_command = DELETE;
        output.organized_input = deleteFrom ( input );
    }
    else if ( regex_match(input, _truncate_table_rgx) ) {
        output.my_command = TRUNCATE;
        output.organized_input = truncateTable ( input );
    }
    else if ( regex_match(input, _update_rgx) ) {
        output.my_command = UPDATE;
        output.organized_input = update ( input );
    }
    else if ( regex_match(input, _select_from_rgx) ) {
        output.my_command = SELECT;
        output.organized_input = select ( input );
    }
    else if ( regex_match(input, _quit_rgx) ) {
        output.my_command = QUIT;
    }
    else {
        throw RegexSyntaxError();            //lancia un'eccezione nel caso in cui la query non venga riconosciuta
    }

    return output;                           //l'output verrà gestito dalla classe database manager
}


list<string> RegexProcessor::createTable (const string& input) {
    list<string> output;                //il risultato finale

    string table_key;                   //contiene il nome della tabella
    list<string> splitted_input;        //contiene le varie "righe" lette
    list<string> column_info;           //contiene le informazioni relative ai campi
    string primary_key;                 //contiene la primary key
    list<string> foreign_info;          //contiene le informazioni relative ai collegamenti foreign
    list<string> column_names;          //contiene i nomi dei campi
    list<string> foreign_names;         //contiene i nomi dei campi foreign
    int column_keys_number;             //il numero di campi inseriti
    int foreign_keys_number;            //il numero di campi foreign
    int primary_key_number = 0;         //il numero di primary keys; alla fine funzione dovrà essere 1
    bool primary_key_flag = false;      //vero se la chiave primary e' una chiave di una colonna inizializzata
    smatch match_result;
    list<string>::iterator it;

    regex_match (input, match_result, _create_table_rgx);
    checkKey(match_result[1]);
    table_key = match_result[1];                                                //salvo la table_key
    output.push_back( table_key );                                              //la mando in output
    splitted_input = stringSplit(match_result[2], ',');     //separo le informazioni lette

    bool end=false;             //true se una "righa" è costituita da spazi (accettabile solo alla fine)
    for ( const string& line : splitted_input ) {     //per ogni "riga" letta controllo che tipo di informazioni contiene
        if (end) {
            throw CreateSyntaxError();
        }
        if ( regex_match(line, match_result, _create_field_info_rgx) ) {  //se la riga corrisponde all'inizializzazione di un campo
            checkKey(match_result[1]);
            column_info.push_back( match_result[1] );
            column_names.push_back(match_result[1] );
            column_info.push_back( match_result[2] );
            if ( match_result[3] != "" ) {
                if ( regex_match(match_result.str(3), _not_null_rgx) ) {        //controllo se c'e' l'informazione not null
                    column_info.emplace_back( "NOT_NULL" );
                }
                if ( regex_match(match_result.str(3), _auto_increment_rgx) ) {  //controllo se c'e' l'informazione auto increment
                    if ( match_result[2] != "INT" ) {
                        throw AutoIncrementError();                                    //eccezione se la colonna e' autoincrement ma non int
                    }
                    column_info.emplace_back( "AUTO_INCREMENT" );
                    column_info.emplace_back( "1" );
                }
            }
        }

        else if ( regex_match(line, match_result, _create_primary_key_rgx) ) {      //se la riga corrisponde all'inizializzazione della primary
            primary_key = match_result[1];
            primary_key_number++;                                                      //questa operazione viene eseguita ogni volta che trova una foreign, quindi dovrà essere una
        }

        else if ( regex_match(line, match_result, _create_foreign_info_rgx ) ) {    //se la riga corrisponde all'inizializzazione di un collegamento foreign
            if ( match_result[2] == table_key ) {                                      //se la table collegata e' la stessa che sta venendo creata ci sarà errore
                throw ForeignTableError();
            }
            for ( int i=0; i<3; i++ ) {
                foreign_info.push_back(match_result[i+1]);
            }
            foreign_names.push_back(match_result[1] );
        }
        else if ( regex_match(line, _spaces_rgx)) {
            end=true;
        }
        else {
            throw CreateSyntaxError();
        }
    }
    column_keys_number = column_names.size();           //salvo il numero di campi inizializzati
    column_names.unique();                              //questa funzione serve per controllare che una chiave non sia stata passata due volte
    foreign_keys_number = foreign_names.size();
    foreign_names.unique();

    for (string & column_key : column_names){           //controllo che la primary key sia un campo "in costruzione"
        if (column_key == primary_key) {
            primary_key_flag = true;
        }
    }

    for (string & foreign_key : foreign_names)  {       //controllo che i campi foreign siano campi "in costruzione"
        bool flag=false;
        for (string & column_key : column_names) {
            if ( foreign_key == column_key ) {
                flag = true;
            }
        }
        if ( !flag ) {              //se almeno una chiave foreign NON e' stata inizializzata
            throw ForeignDeclarationError();
        }
    }

    if ( column_keys_number != column_names.size() ) {  //l'attuale column_key ha subito la funzione unique; quindi se la size e' cambiata, un campo e' stato inizializzato due volte
        throw SeveralFieldsError();
    }
    if ( foreign_keys_number != foreign_names.size() ) {
        throw SeveralForeignError();
    }
    if ( primary_key_number != 1 || !primary_key_flag ) {
        throw PrimaryKeyError();
    }

    output.splice( output.end(),column_info );      //mando in output tutte le informazioni relative ai campi
    output.emplace_back( "PRIMARY" );                  //mando in output PRIMARY
    output.push_back( primary_key );                   //mando in output la primary key
    if ( !foreign_info.empty() ) {                     //se ci sono collegamenti FOREIGN
        output.emplace_back( "FOREIGN" );              //mando in output FOREIGN
        output.splice( output.end(),foreign_info ); //mando in output tutte le informazioni relative ai collegamenti foreign
    }
    return output;
}

//ritorna il nome della tabella da eliminare (dentro una lista)
list<string> RegexProcessor::dropTable (const string& input) {
    smatch match_result;
    list<string> output;
    regex_match(input, match_result, _drop_table_rgx);
    output.push_back( match_result[1] );
    return output;
}

//ritorna il nome della tabella da svuotare (dentro una lista)
list<string> RegexProcessor::truncateTable (const string& input) {
    smatch match_result;
    list<string> output;
    regex_match(input, match_result, _truncate_table_rgx);
    output.push_back( match_result[1] );
    return output;
}


list<string> RegexProcessor::insertInto (const string& input) {
    list<string> output;
    string table_name;                      //contiene il nome della tabella
    list<string> splitted_keys;             //contiene le chiavi passate
    list<string> splitted_values;           //contiene i valori passati
    int number_of_keys = 0;                 //il numero di chiavi passate
    int number_of_values = 0;               //il numero di valori passati
    smatch match_result;

    regex_match(input, match_result, _insert_into_rgx );
    table_name = match_result[1];                                                   //salvo la key della tabella
    splitted_keys = stringSplit( match_result[2], ',' );        //separo le chiavi passate
    splitted_values = stringSplit( match_result[3], ',' );      //separo i valori passati

    for ( string & splitted_key : splitted_keys ) {
        regex_match(splitted_key, match_result, _type_key_rgx );
        output.push_back( match_result[1] );                                  //accodo in output le chiavi passate
        number_of_keys++;
    }

    output.unique();    //l'output non contiene ancora il nome della tabella
    if ( output.size() != number_of_keys ) {     //controllo che un campo non venga passato due volte
        throw SeveralInsertError();
    }

    output.push_front( table_name );    //inserisco il nome della tabella nell'output
    output.emplace_back( "VALUES" );

    for ( string & splitted_value : splitted_values ) {
        output.splice( output.end(), valueIdentifier(splitted_value) );     //salvo i valori passati con il loro tipo
        number_of_values++;
    }

    if ( number_of_keys != number_of_values ) {     //errore se il numero delle chiavi passati differisce da quello dei valori
        throw DifferentNumbersInsertError();
    }
    return output;
}


list<string> RegexProcessor::deleteFrom ( const string& input ) {
    list<string> output;
    smatch match_result;

    regex_match(input, match_result, _delete_from_rgx );

    output.push_back( match_result[1] );                            //salvo il nome della tabella
    output.splice( output.end(), where( match_result, 2) );    //salvo le informazioni del WHERE
    return output;
}


list<string> RegexProcessor::update (const string& input) {
    list<string> output;
    list<string> setting_info;          //contiene le informazioni di set (es: ID=4)
    smatch match_result;
    list<string> fields;                //contiene i nomi dei campi passati
    int fields_number;                  //contiene il numero dei campi passati

    regex_match(input, match_result, _update_rgx );
    output.push_back( match_result[1] );                                    //salvo la key della tabella
    setting_info = stringSplit( match_result[2], ',' );   //separo le informazioni di set
    for ( string & it : setting_info ) {
        if ( regex_match(it, _update_setting_rgx) ) {
            smatch set_match_result;
            regex_match(it, set_match_result, _update_setting_rgx );
            output.push_back( set_match_result[1] );                        //salvo il nome del campo
            fields.push_back(set_match_result[1] );
            output.splice( output.end(), valueIdentifier(set_match_result[2]) );    //salvo il tipo e il valore passato
        }
        else{         //se la scrittura delle informazioni di set e' sbagliata, lancio un'eccezione
            throw UpdateSyntaxError();
        }
    }
    output.emplace_back( "WHERE" );
    output.splice( output.end(), where(match_result, 3) );  //salvo le informazioni del WHERE

    fields_number = fields.size();
    fields.unique();
    if (fields_number != fields.size() ) {  //controllo che un campo non venga inserito più volte
        throw SeveralFieldsUpdateError();
    }

    return output;
}


list<string> RegexProcessor::select (const string& input) {
    list<string> output;
    smatch match_result;
    list<string> fields;
    list<string> my_list;
    int fields_number;

    regex_match(input, match_result, _select_from_rgx);
    if ( match_result[1] == "*" ) {                                              //se viene passata la select *
        fields.push_back( match_result[1] );
    }
    else {
        my_list = stringSplit( match_result[1], ',' );      //separo i campi passati
        for ( string & it : my_list ) {
            smatch match_result_2;
            if ( regex_match(it, match_result_2, _type_key_rgx ) ) {         //controllo che siano giusti
                fields.push_back( match_result_2[1] );                        //salvo il nome del campo passato
            }
            else {      //lancio un'eccezione se i campi sono scritti male
                throw FieldsSelectError();
            }
        }
    }
    output.push_back( match_result[2] );              //salvo il nome della tabella
    fields_number = fields.size();
    fields.unique();
    if ( fields_number != fields.size() ) {
        throw SeveralFieldsSelectError();
    }
    output.splice( output.end(), fields );

    if ( match_result[3] != "" ) {                       //le istruzioni di controllo e di output del where sono le stesse della delete
        output.emplace_back( "WHERE" );
        output.splice( output.end(), where (match_result,3) );
    }
    if ( match_result[9] == "ORDER" ) {                 //se c'e' l'order, stampo ORDER -> il nome del campo -> ASC (o DESC)
        for ( int i=9; i<12; i++ ) {
            output.push_back( match_result[i] );
        }
    }
    return output;
}

//index dev'essere l'indice di input corrispondente al capturing group del campo:   WHERE (campo)
list<string> RegexProcessor::where (const smatch& input, int index) {
    string comparison_symbol;   //contiene l'operatore di confronto o BETWEEN
    string type;                //contiene il tipo dei valori
    list<string> values;        //contiene i valori
    list<string> type_and_value;    //contiene un tipo e un valore
    list<string> output;

    if ( input[index + 3] == "BETWEEN" ) {          //se la condizione di confronto è BETWEEN
        comparison_symbol = "BETWEEN";
        string second_type;                         //contiene il tipo del secondo valore
        list<string> second_type_and_value;         //contiene tipo e valore del secondo valore
        type_and_value = valueIdentifier( input[index + 4] );
        second_type_and_value = valueIdentifier( input[index + 5] );
        type = type_and_value.front();
        second_type = second_type_and_value.front();
        values.push_back( type_and_value.back() );
        values.push_back( second_type_and_value.back() );
        if (type == second_type) {          //se i due tipi sono concordi va bene
        }
        else if ((type == "INT" || second_type == "FLOAT") && (second_type == "INT" || type == "FLOAT") ) {
            type = "FLOAT";                 //se i due tipi sono uno int e l'altro float, salverò float
        }
        else {                              //se i due tipi sono discordi, lancio un'eccezione
            throw WhereTypeError();
        }
    }
    else {
        comparison_symbol = input[index + 1];
        checkSymbol(comparison_symbol);     //controllo che l'operatore di confronto sia giusto
        type_and_value = valueIdentifier(input[index + 2] );
        type = type_and_value.front();
        values.push_back(type_and_value.back() );
        if (type == "UNKNOWN" && comparison_symbol != "=" ) {   //solo l'operatore = può essere seguito da default
            throw WhereDefaultError();
        }
    }
    output.push_back( input[index] );       //salvo il nome del campo
    output.push_back( type );               //salvo il tipo dei valori
    output.push_back( comparison_symbol );  //salvo l'operatore di confronto
    output.splice( output.end(), values );  //salvo i valori

    return output;
}

//controllo che i nomi di campi/tabelle non siano parole riservate
void RegexProcessor::checkKey (const string& key) {
    list<string> reserved_keywords = {   //"dizionario" di parole riservate
        "CREATE", "TABLE", "PRIMARY", "KEY", "FOREIGN", "REFERENCES", "AUTO_INCREMENT", "INT", "FLOAT", "TEXT", "DATE", "TIME", "CHAR",
        "DROP",
        "TRUNCATE",
        "DELETE", "FROM",
        "INSERT", "INTO", "VALUES",
        "UPDATE", "SET",
        "SELECT", "ORDER", "BY", "ASC", "DESC",
        "WHERE", "BETWEEN",
        "QUIT",
    };

    for ( string& x : reserved_keywords ) {
        if ( x == key ) {
            cerr << key << ": ";
            throw ReservedKeyError();
        }
    }
}

//controllo che l'operatore di confronto nel WHERE sia accettabile
void RegexProcessor::checkSymbol (const string& symbol) {
    if ( symbol!="=" && symbol!="<" && symbol!=">" && symbol!="<=" && symbol!=">=" && symbol!="<>") {
        cerr << symbol << ": ";
        throw InvalidSymbolError();
    }
}