//
// Created by Avalle Dario, De Carlo Francesca, Fagnani Pietro
//

#include "Database.h"


Database::~Database() {
    _tables.clear();
}


void Database::createTableDB ( list<string>& organized_query ) {
    vector<campo*> reference;

    if ( find( _tables.begin(), _tables.end(), *organized_query.begin() ) != _tables.end() )
        throw ExistingTable();

    reference = getReferencePointers (organized_query);
    //mette nel vettore reference i puntatori ai campi a cui le foreign keys della tabella da creare sono collegate

    _tables.push_back( Table(organized_query, reference) );
}


void Database::dropDB ( const string& table_key ) {
    findTable( table_key );

    for (Table& table : _tables) {          //se la tabella da eliminare è collegata esternamente, chiede conferma di eliminazione e memorizza
        table.checkReference(table_key);    //all'interno della tabella i collegamenti da eliminare nel caso di conferma
    }

    for (Table& table : _tables) {
        table.setReferencePointersToNull(table_key);
    }

    _iterator -> clearTable();
    _tables.erase(_iterator );
}


void Database::truncateDB ( const string& table_key ) {
    findTable( table_key );
    _iterator -> clearTable();
}


void Database::insertIntoTableDB (list<string>& organized_query){
    findTable( *organized_query.begin() );
    organized_query.pop_front();            //elimino nome tabella
    _iterator -> addRecord(organized_query );
}


int Database::deleteFromDB ( list<string> &organized_query ) {
    findTable( *organized_query.begin() );
    organized_query.pop_front() ;
    return _iterator->deleteFrom(organized_query);;
}


int Database::updateDB ( list<string> &organized_query ) {
    findTable( *organized_query.begin() );
    organized_query.pop_front();
    return _iterator -> update(organized_query );
}


void Database::selectFromDB ( list<string>& organized_query ) {
    findTable( *organized_query.begin() );
    organized_query.pop_front();                         //elimino nome tabella
    _iterator -> select(organized_query );
}


void Database::readDatabase ( ifstream &f ) {
    list<string> table_info;
    string str;
    int n_tabelle;
    vector<campo *> reference;
    f >> n_tabelle;                                                     //numero di tabelle
    for ( int i = 0; i < n_tabelle; i++ ) {                             //leggo le informazioni sulla tabella
        f >> str;
        while (str != "*") {
            table_info.push_back(str);
            f >> str;
        }
        reference = getReferencePointers(table_info );
        _tables.emplace_back( Table(table_info, reference) );       //creo la tabella
        _tables.back().readTable( f );                              //leggo la tabella
        table_info.clear();
    }
}


void Database::writeDatabase ( ofstream& f ) {
    f << _tables.size() ;
    for (_iterator = _tables.begin(); _iterator != _tables.end(); _iterator++ ) {
        _iterator -> writeTable (f);
    }
}


void Database::findTable ( const string& table_key ) {
    _iterator = find(_tables.begin(), _tables.end(), table_key );
    if (_iterator == _tables.end() ) {
        cerr << table_key << ": ";
        throw NotFoundTable();
    }
}


vector<campo*> Database::getReferencePointers ( list<string>& table_info ) {
    list<string>::iterator it=table_info.end();
    string table_key;
    string field_key;
    vector<campo*> reference;

    do { it--; }
    while ( *it != "FOREIGN" && *it != "PRIMARY" ); //se trova prima PRIMARY, vuol dire che FOREIGN non c'è

    if ( *it == "FOREIGN" ) {
        while (++it != table_info.end() ) {
            table_key = *++it; //salvo i dati relativi alla reference
            field_key = *++it;

            findTable( table_key );

            reference.push_back(_iterator->getFieldPointer(field_key) );

            if (_iterator->_primary_key != field_key){
                cerr << field_key << " : ";
                throw NotPrimary();
            }
        }
    }
    return reference;
}


string Database::getTableKeys() {
    string ret;
    ret = "Numero tabelle: " + to_string(_tables.size()) + "\n\n";
    for (_iterator = _tables.begin(); _iterator != _tables.end(); _iterator++ ) {
        ret += _iterator->getKey();
        ret += "\n";
    }

    return ret;
}