//
// Created by Avalle Dario, De Carlo Francesca, Fagnani Pietro
//

#include "DatabaseManager.h"

int main() {
    DatabaseManager my_manager;
    my_manager.load();
    bool exit;

    do {
        exit = my_manager.query();
    } while ( !exit );
    try {
        my_manager.save();
    }
    catch ( OpeningFileError &e ) {
        cerr << e.what();
    }
    cout << "Arrivederci";

    return 0;
}