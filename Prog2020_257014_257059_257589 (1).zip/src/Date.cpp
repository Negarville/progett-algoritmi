//
// Created by Avalle Dario, De Carlo Francesca, Fagnani Pietro
//

#include "Date.h"

Date::Date() {
    this -> _day = 0;
    this -> _month = 0;
    this -> _year = 0;
}


Date::Date ( const int &d, const int &m, const int &y ) {
    this -> _day = d;
    this -> _month = m;
    this -> _year = y;
}


string Date::str() const {
    ostringstream stream;
    stream << setfill('0') << setw(2) << this -> _day ;
    stream << "/" << setfill('0') << setw(2) << this -> _month;
    stream <<  "/" <<setfill('0') << setw(4) << this -> _year;
    return stream.str();
}


bool Date::operator== ( const Date &to_compare ) const {
    return ((this -> _day == to_compare._day) &&
            (this -> _month == to_compare._month) &&
            (this -> _year == to_compare._year) );
}


bool Date::operator!= ( const Date &to_compare ) const {
    return !( *this == to_compare );
}


bool Date::operator> ( const Date &to_compare ) const {
    std::ostringstream os;
    os <<  setfill('0') << setw(4) << this -> _year ;
    os << setfill('0') << setw(2) << this -> _month ;
    os << setfill('0') << setw(2) << this -> _day ;
    //std::string str1 = os.str();

    std::ostringstream os2;
    os2 <<  setfill('0') << setw(4) << to_compare._year ;
    os2 << setfill('0') << setw(2) << to_compare._month ;
    os2 << setfill('0') << setw(2) << to_compare._day ;
    //std::string str2= os2.str();
    return ( os.str() > os2.str() );
}


bool Date::operator< ( const Date &to_compare ) const{
    return ( !(*this > to_compare) && !(*this==to_compare));
}


ostream& operator<< ( std::ostream& stream, const Date& d ) {
    stream << d.str();
    return stream;
}


istream& operator>> ( std::istream& stream, Date & d ) {  //legge la data da una stringa gg/mm/aaaa
    char c;
    int dayx, monthx, yearx;
    stream >> dayx >> c >> monthx >> c >> yearx;
    d = Date( dayx, monthx, yearx );
    return stream;
}