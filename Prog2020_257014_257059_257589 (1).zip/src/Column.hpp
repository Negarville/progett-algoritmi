//
// Created by Avalle Dario, De Carlo Francesca, Fagnani Pietro
//

#ifndef PROGETTO_COLUMN_HPP
#define PROGETTO_COLUMN_HPP

#include <fstream>
#include <vector>
#include <algorithm>
#include "Date.h"
#include "Time.h"
#include "setting.h"

using namespace std;

template <typename T>
class Column {
public:
    Column(){};
    ~Column();
    Column( const Column& to_copy );
    Column& operator= ( const Column& to_be_assigned );

    void resize ( const int& n );
    T readElement ( const string& str );
    vector<T> readElements ( const vector<string>& str_values );

    void addElementFromString ( const string& record );
    void addElement ( T value );

    const T& getElement ( const int& n ) const;
    T& getReferenceToElement (const int& n );

    //Restituiscono un vettore contenente gli indici degli elementi contenuti nell’intervallo di valori richiesto.
    vector<int> findElements ( const string& operatore, const vector<T>& values );
    vector<int> findElementsEqualTo ( const T& value );

    vector<int> compare ( bool(Column<T>::*f)(T,T) , T val );
    vector<int> compare ( bool(Column<T>::*f1)(T,T) , T val1, bool(Column<T>::*f2)(T,T), T val2, bool AND );

    //Riceve gli indici dei valori da ordinare in ordine crescente oppure decrescente. Restituisce un vettore
    //contenente gli indici disposti nell’ordine in cui devono essere stampati
    vector<int> orderElements ( vector<int> record, string &order );

    bool isInColumn (const T& dato );

    void deleteElements( vector<int>& index );
    void updateElements (vector<int>& index, const T& element );
    void clearColumn();

    bool equal ( T val1, T val2 ) {
        return ( val1 == val2 );
    }
    bool greater ( T val1, T val2 ) {
        return ( val1 > val2 );
    }
    bool smaller ( T val1, T val2 ) {
        return ( val1 < val2 );
    }
    bool notEqual (T val1, T val2 ) {
        return !equal( val1, val2 );
    }

private:
    vector<T> _column_values;
    typename vector<T>::iterator _it;
};

#endif //PROGETTO_COLUMN_HPP

template <typename T>
Column<T>::~Column(){
     _column_values.clear();
}

template <typename T>
Column<T>::Column ( const Column& to_copy ) {
    _column_values = to_copy._column_values;
}

template <typename T>
Column<T>& Column<T>::operator= ( const Column& to_be_assigned ) {
    _column_values = to_be_assigned._column_values;
    return *this;
}

template <typename T>
void Column<T>::resize ( const int& n ) {
    _column_values.resize(n );
}

template <typename T>
T Column<T>::readElement ( const string& str ) {
    T dato;
    istringstream is(str);
    is >> dato;
    return dato;
}

template <typename T>
vector<T> Column<T>::readElements ( const vector<string>& str_values ) {
    int i = 0;
    vector<T> values;

    while ( i < str_values.size() ) {
        T dato;
        istringstream is( str_values[i] );
        is >> dato;
        values.push_back( dato );
        i++;
    }

    return values;
}

template <typename T>
void Column<T>::addElementFromString ( const string& record ) {
    T dato = readElement ( record );
    _column_values.push_back( dato );
}

template <typename T>
void Column<T>::addElement ( T value ) {
    _column_values.push_back( value );
}

template <typename T>
const T& Column<T>::getElement ( const int& n ) const{
    return _column_values[n];
}

template <typename T>
T& Column<T>::getReferenceToElement (const int& n ) {
    return _column_values[n];
}

template <typename T>
vector<int> Column<T>::findElements ( const string& operatore, const vector<T>& values ) {
    if ( operatore == "=" )
        return compare ( this->Column<T>::equal, values[0] );
    
    else if ( operatore == ">" )
        return compare ( this->Column<T>::greater, values[0] );
    
    else if ( operatore == "<" )
        return compare ( this->Column<T>::smaller, values[0] );
    
    else if ( operatore == "<=" )
        return compare ( this->Column<T>::smaller, values[0], this->Column<T>::equal, values[0], false );
    
    else if ( operatore == ">=" )
        return compare ( this->Column<T>::greater, values[0], this->Column<T>::equal, values[0], false );
    
    else if ( operatore == "BETWEEN" )
        return compare ( this->Column<T>::greater, values[0], this->Column<T>::smaller, values[1], true );
    
    else return compare(this->Column<T>::notEqual, values[0]);
}

template <typename T>
vector<int> Column<T>::findElementsEqualTo ( const T &value ) {
    return compare ( this->Column<T>::equal, value );
}

template <typename T>
vector<int> Column<T>::compare ( bool(Column<T>::*f)(T,T) ,T val ) {
    vector<int> index;
    _it = _column_values.begin();
    for ( _it = _column_values.begin(); _it != _column_values.end(); _it++ )
        if( (this->*f)(*_it,val) )
            index.push_back(_it - _column_values.begin() );
    return index;
}

template <typename T>
vector<int> Column<T>::compare ( bool(Column<T>::*f1 )(T,T), T val1, bool(Column<T>::*f2)(T,T), T val2, bool AND ) {
    vector<int> index;
    _it = _column_values.begin();

    for ( _it = _column_values.begin(); _it != _column_values.end(); _it++ ) {
        if ( AND ) {
            if ( (this->*f1)(*_it,val1) && (this->*f2)(*_it,val2) )
                index.push_back(_it - _column_values.begin() );
        }
        else {
            if ( (this->*f1)(*_it,val1) || (this->*f2)(*_it,val2) )
                index.push_back( _it - _column_values.begin() );
        }
    }
    return index;
}

template <typename T>
vector<int> Column<T>::orderElements ( vector<int> record, string &order ) {
    vector<int> ordered_records;
    ordered_records.push_back(record[0]);

    for ( int i=1; i<record.size(); i++ ) {
        for (int k=0; k < ordered_records.size(); k++ ) {
            if ( order == "ASC" ) {
                if ( smaller(_column_values[record[i]], _column_values[ordered_records[k]]) ) {
                    ordered_records.insert(ordered_records.begin() + k, record[i] );
                    k = ordered_records.size();
                }
            }
            if ( order == "DESC" ) {
                if ( greater(_column_values[record[i]], _column_values[ordered_records[k]]) ) {
                    ordered_records.insert(ordered_records.begin() + k, record[i] );
                    k=ordered_records.size();
                }
            }
            if (k == ordered_records.size() - 1 ) {
                ordered_records.push_back(record[i] );
                k++;
            }
        }
    }

    return ordered_records;
}

template <typename T>
bool Column<T>::isInColumn (const T& dato ) {
    _it = find(_column_values.begin(), _column_values.end(), dato );
    return (_it != _column_values.end() );
}

template <typename T>
void Column<T>::deleteElements(vector<int>& index){
    int i = index.size();

    while( i > 0 ) {
        i--;
        _column_values.erase(_column_values.begin() + index[i]);
    }
}

template <typename T>
void Column<T>::updateElements (vector<int>& index, const T& element ) {
    for (int& i : index)
        _column_values[i] = element;
}

template <typename T>
void Column<T>::clearColumn() {
    _column_values.clear();
}
