//
// Created by Avalle Dario, De Carlo Francesca, Fagnani Pietro
//

#ifndef PROGETTO_DATABASEMANAGER_H
#define PROGETTO_DATABASEMANAGER_H

#include "Database.h"
#include "RegexProcessor.h"

class DatabaseManager {
public:
    void load ();                       //carica il database
    string readUntil (char last_char);  //legge la query
    bool query ();                      //esegue la query
    void save ();                       //salva il database

private:
    Database _my_database;
    RegexProcessor _input_processor;
    bool _changes_flag; //true se una query apporta delle modifiche al database
};

#endif //PROGETTO_DATABASEMANAGER_H