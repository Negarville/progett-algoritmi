//
// Created by Avalle Dario, De Carlo Francesca, Fagnani Pietro
//

#ifndef PROGETTO_DATABASE_H
#define PROGETTO_DATABASE_H

#include "Table.h"

class Database {
public:
    Database() { };
    ~Database();

    void createTableDB (list<string>& organized_query);
    void dropDB (const string& table_key);
    void truncateDB (const string& table_key);
    void insertIntoTableDB (list<string>& organized_query);
    int deleteFromDB (list<string>& organized_query);   //ritorna il numero di record cancellati
    int updateDB (list<string>& organized_query);   //ritorna il numero di record aggiornati
    void selectFromDB (list<string>& organized_query);
    void readDatabase (ifstream& f);
    void writeDatabase (ofstream& f);
    void findTable (const string& table_key);
    string getTableKeys();  //ritorna l'elenco dei nomi delle tabelle presenti

    vector<campo*> getReferencePointers (list<string>& table_info);
    //Controlla se alla nuova tabella da creare devono essere collegati dei campi e, in caso affermativo, cerca i campi e memorizza
    // i puntatori nel vettore restituito


private:
    list<Table> _tables;
    list<Table>::iterator _iterator;
};

#endif //PROGETTO_DATABASE_H