//
// Created by Avalle Dario, De Carlo Francesca, Fagnani Pietro
//

#ifndef PROGETTO_REGEXPROCESSOR_H
#define PROGETTO_REGEXPROCESSOR_H


#include <fstream>
#include <regex>
#include <list>
#include <algorithm>
#include "Eccezioni.h"
#include "setting.h"

using namespace std;
struct RegexOutput {
    RegexCommand my_command;
    list<string> organized_input;
};

class RegexProcessor {
private:
    //stringhe corrispondenti alle sintassi dei possibili tipi
    string _type_integer = R"([-+]?[0-9]+)";
    string _type_float = R"([-+]?[0-9]+\.[0-9]+)";
    string _type_date = R"((?:(?:[1-2][0-9])|0[1-9]|3[0-1])/(?:0[1-9]|1[0-2])/[0-9]{4})";
    string _type_date_matching = R"(((?:[1-2][0-9])|0[1-9]|3[0-1])/(0[1-9]|1[0-2])/([0-9]{4}))";
    string _type_time = R"((?:(?:[0-1][0-9])|2[0-3]):[0-5][0-9]:[0-5][0-9])";
    string _type_char = R"('(?:\\?.|\n)')";
    string _type_text_generic = R"("(?:.|\n)*")";
    string _type_text_matching = R"((")((?:(?=(\\?))\4(?:.|\n))*?)\2)";
    string _type_key = R"([0-9A-Z_]+)";

    //regex corrispondenti ai possibili tipi
    regex _default_rgx = regex (R"(^\s*DEFAULT\s*$)");
    regex _type_integer_rgx = regex (R"(^\s*()" + _type_integer + R"()\s*$)");
    regex _type_float_rgx = regex (R"(^\s*()" + _type_float + R"()\s*$)");
    regex _type_date_matching_rgx = regex (R"(^\s*()" + _type_date_matching + R"()\s*$)");
    regex _type_time_rgx = regex (R"(^\s*()" + _type_time + R"()\s*$)");
    regex _type_char_rgx = regex (R"(^\s*()" + _type_char + R"()\s*$)");
    regex _type_text_matching_rgx = regex (R"(\s*()" + _type_text_matching + R"()\s*)");
    regex _type_key_rgx = regex (R"(^\s*()" + _type_key + R"()\s*$)");

    //stringhe ricorrenti nelle regex
    string _type_everytype = R"(((?:)" + _type_float + R"()|(?:)" + _type_date + R"()|(?:)" + _type_time + R"()|(?:)" + _type_integer + R"()|(?:)" + _type_char + R"()|(?:)" + _type_text_generic + R"()))";
    string _type_everytype_with_default = R"(((?:)" + _type_float + R"()|(?:)" + _type_date + R"()|(?:)" + _type_time + R"()|(?:)" + _type_integer + R"()|(?:)" + _type_char + R"()|(?:)" + _type_text_generic + R"()|(?:DEFAULT)))";
    string _several_type_key = R"([0-9A-Z_,\s]+)";
    string _possible_types = R"((?:INT|FLOAT|CHAR|TEXT|DATE|TIME))";
    string _generic = R"((?:.|\n)+)";
    string _not_null = R"((?:NOT NULL(?:\s+AUTO_INCREMENT)?)|(?:(?:AUTO_INCREMENT\s+)?NOT NULL))";
    string _auto_increment = R"((?:(?:NOT NULL\s+)?AUTO_INCREMENT)|(?:AUTO_INCREMENT(?:\s+NOT NULL)?))";
    string _where_expression = R"(WHERE\s+()" + _type_key + R"()\s*(?:(?:([=<>]{1,2})\s*)" + _type_everytype_with_default + R"()|(?:(BETWEEN)\s*)" + _type_everytype + "\\s*AND\\s*" + _type_everytype + R"())\s*)";

    //regex corrispondenti alle query
    regex _create_table_rgx = regex(R"(^\s*CREATE\s+TABLE\s+()" + _type_key + R"()\s+\(\s+()" + _generic + R"()\s*\)\s*;$)");
    regex _drop_table_rgx = regex (R"(^\s*DROP\s+TABLE\s+()" + _type_key + R"()\s*;$)");
    regex _insert_into_rgx = regex (R"(^\s*INSERT\s+INTO\s+()" + _type_key + R"()\s*\(()" + _several_type_key + R"()\)\s*VALUES\s*\(\s*()" + _generic + R"()\s*\)\s*;$)");
    regex _delete_from_rgx = regex (R"(^\s*DELETE\s+FROM\s+()" + _type_key + R"()\s+)" + _where_expression + ";$");
    regex _truncate_table_rgx = regex (R"(^\s*TRUNCATE\s+TABLE\s+()" + _type_key + R"()\s*;$)");
    regex _update_rgx = regex (R"(^\s*UPDATE\s+()" + _type_key + R"()\s+SET\s+()" + _generic + R"()\s+)" + _where_expression + ";$");
    regex _select_from_rgx = regex (R"(^\s*SELECT\s+()" + _generic + R"()\s+FROM\s+()" + _type_key + R"()(?:\s+)" + _where_expression + ")?" + R"((?:\s+(ORDER)\s+BY\s+()" + _type_key + R"()\s+(DESC|ASC))?\s*;$)");
    regex _quit_rgx = regex (R"(^\s*QUIT\s*\(\s*\)\s*;$)");

    //regex necessarie per la query CREATE
    regex _create_field_info_rgx = regex (R"(^\s*()" + _type_key + R"()\s+()" + _possible_types + R"()\s*()" + _not_null + "|" + _auto_increment + R"()?\s*$)");
    regex _not_null_rgx = regex ("^" + _not_null + "$" );
    regex _auto_increment_rgx = regex ("^" + _auto_increment + "$");
    regex _create_primary_key_rgx = regex (R"(^\s*PRIMARY\s+KEY\s+\(\s*()" + _type_key + R"()\s*\)\s*$)");;
    regex _create_foreign_info_rgx = regex (R"(^\s*FOREIGN\s+KEY\s*\(\s*()" + _type_key + R"()\s*\)\s+REFERENCES\s+()" + _type_key + R"()\s+\(\s*()" + _type_key + R"()\s*\)\s*$)");
    regex _spaces_rgx = regex (R"(^\s+$)");

    //regex necessarie per la query UPDATE
    regex _update_setting_rgx = regex (R"(^\s*()" + _type_key + R"()\s*=\s*)" + _type_everytype + R"(\s*$)");

public:
    RegexOutput functionIdentifier (const string& input);                                   //identifica la query

    //metodi ausiliari
    list<string> stringSplit (const string& input_string, const char& splitting_char);      //divide una stringa in una lista
    list<string> valueIdentifier (const string& input);                                     //riconosce il tipo di un valore
    void checkKey (const string& key);                                                      //controlla la validità di una chiave
    void checkSymbol(const string& symbol);                                                 //controlla la validità di un operatore
    list<string> where (const smatch& input, int index);                                    //gestisce l'analisi della condizione where

    //metodi relativi alle query
    list<string> createTable (const string& input);
    list<string> dropTable (const string& input);
    list<string> insertInto (const string& input);
    list<string> deleteFrom (const string& input);
    list<string> truncateTable (const string& input);
    list<string> update (const string& input);
    list<string> select (const string& input);
};

#endif //PROGETTO_REGEXPROCESSOR_H