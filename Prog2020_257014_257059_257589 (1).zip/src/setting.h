//
// Created by Avalle Dario, De Carlo Francesca, Fagnani Pietro
//

#define int_default INT_MIN
#define float_default -__FLT_MAX__ //-3.40282e+38
#define char_default ' '
#define text_default "\"\""
#define time_default Time()
#define date_default Date()
#define default_value 'D'
#define column_width 16
#define column_width_text 26
#define r_arrow "-> "

#define saving_file "database.txt"

#pragma once
enum RegexCommand {CREATE, DROP, INSERT, DELETE, TRUNCATE, UPDATE, SELECT, QUIT};
enum type {INT, FLOAT, CHAR, TIME, DATE, TEXT, NOT_IDENTIFIED};