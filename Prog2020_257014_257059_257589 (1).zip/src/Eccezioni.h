//
// Created by Avalle Dario, De Carlo Francesca, Fagnani Pietro
//

#ifndef PROGETTO_ECCEZIONI_H
#define PROGETTO_ECCEZIONI_H

#include <exception>
#include <iostream>

using namespace std;

class OpeningFileError : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Errore nella apertura del file";};
};

class NotFoundTable : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Tabella non trovata";};
};

class ExistingTable : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Tabella gia' esistente";};
};

class NotFoundColumn : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Campo non esistente";};
};

class ForeignTypesError : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Non è possibile effettuare il collegamento: i campi contengono dati di tipo diverso";};
};

class NotNullException : public exception {
    using exception::exception;

public:
    const char* what() const noexcept { return "Necessario assegnare un valore a questo campo";};
};

class AutoIncrementException : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Impossibile assegnare valore a campo AUTO_INCREMENT";};
};

class NotAcceptableData : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Formato non accettabile";};
};

class NotUniqueValue : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "La Primary Key non puo' avere due volte questo valore";};
};

class NotInReference : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Valore non presente nel campo a cui la foreign key è collegata";};
};

class NotDrop : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Cancellazione annullata";};
};

//-----------------Eccezioni della classe RegexProcessor--------------------------------------------------------------

class StringSplitError : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Errore di programmazione: carattere di splitting non accettabile (metodo stringSplit della classe RegexProcessor)";};
};

class ValueSyntaxError : public exception{
    using exception::exception;
public:
    const char* what() const noexcept {
        return "Errore di sintassi, valore non riconosciuto. Inserire un valore che rispetti le seguenti sintassi:\n"
               " - INT: un numero intero positivo o negativo (il segno e' omissibile)\n"
               " - FLOAT: un numero decimale positivo o negativo (il segno e' omissibile). Utilizzare la notazione posizionale\n"
               " - CHAR: un carattere case sensitive nel formato 'c'. Se si desidera inserire un singolo apice come carattere, bisogna che questo sia preceduto da un backslash\n"
               " - TEXT: un testo case sensitive preceduto e seguito da doppi apici (\"). Se si desidera inserire un doppio apice all'interno del testo, bisogna che questo sia preceduto da un backslash\n"
               " - DATE: una data nel formato gg/mm/aaaa ; la data dev'essere accettabile"
               " - TIME: un orario nel formato hh:mm:ss ; l'orario dev'essere accettabile";
    };
};

class DateSyntaxError : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Errore di sintassi, la data non e' accettabile\n";};
};

class RegexSyntaxError : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Errore di sintassi, funzione non riconosciuta\n";};
};

class AutoIncrementError : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Errore di sintassi, i campi definiti come AUTO_INCREMENT devono essere di tipo INT\n";};
};

class ForeignTableError : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Errore nella dichiarazione di un campo FOREIGN: un campo non puo' essere collegato esternamente alla sua tabella di appartenenza\n";};
};

class CreateSyntaxError : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Errore di sintassi all'interno della CREATE: controllare la dichiarazione dei campi";};
};

class ForeignDeclarationError : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Errore nella dichiarazione di un campo FOREIGN: tutti i campi FOREIGN devono essere inizializzati all'interno della loro tabella di appartenenza";};
};

class PrimaryKeyError : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Errore nella dichiarazione della PRIMARY KEY: dev'essere dichiarato un campo primario (e soltanto uno) che dev'essere inizializzato all'interno della tabella";};
};

class SeveralFieldsError : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Errore nella dichiarazione dei campi nella CREATE: un campo non puo' essere inizializzato piu' di una volta";};
};

class SeveralForeignError : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Errore nella dichiarazione dei campi FOREIGN: un campo non puo' essere collegato esternamente piu' di una volta";};
};

class SeveralInsertError : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Errore nella INSERT: un singolo campo non puo' essere passato piu' di una volta alla INSERT";};
};

class DifferentNumbersInsertError : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Errore nella INSERT: il numero di campi dev'essere uguale al numero dei valori";};
};

class UpdateSyntaxError : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Errore di sintassi nella UPDATE: la dichiarazione di SET di un campo non e' stata riconosciuta;"
                                                       " assicurarsi che sia rispettata la seguente sintassi:\n"
                                                       "\t... SET campo1=valore1, campo2=valore2 , ... , campoN=valoreN WHERE ...";};
};

class SeveralFieldsUpdateError : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Errore di sintassi nella UPDATE: un campo non puo' essere aggiornato piu' volte all'interno della stessa UPDATE";};
};

class FieldsSelectError : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Errore di sintassi nella SELECT: un campo non e' stato riconosciuto";};
};

class SeveralFieldsSelectError : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Errore nella SELECT: un campo non puo' essere stampato piu' volte all'interno della stessa SELECT";};
};

class WhereTypeError : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Errore nella condizione WHERE; i valori seguenti BETWEEN devono essere dello stesso tipo";};
};

class WhereDefaultError : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Errore nella condizione WHERE; e' possibile assegnare il valore di default a un campo solo tramite =";};
};

class BackslashError : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "Errore nella lettura: un singolo backslash puo' essere seguito soltanto da 'n', 't', un altro backslash,\n"
                                               "un doppio apice (all'interno dei testi) o un singolo apice (all'interno dei char)";};
};

class NotPrimary : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "non è una primary key";};
};

class ReservedKeyError : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "non e' possibile usare un nome riservato";};
};

class InvalidSymbolError : public exception{
    using exception::exception;
public:
    const char* what() const noexcept { return "simbolo di confronto non accettabile";};
};
#endif //PROGETTO_ECCEZIONI_H