//
// Created by Avalle Dario, De Carlo Francesca, Fagnani Pietro
//

#include "DatabaseManager.h"

//Carica il database dal file di salvataggio
void DatabaseManager::load () {
    ifstream f_in;

    f_in.open( saving_file );   //saving_file è definito in setting.h
    if ( f_in.is_open() ) {     //se è presente un file carica il database
        cout << "Caricamento Database: " << endl;
        _my_database.readDatabase(f_in);
        cout << _my_database.getTableKeys() << endl;
        cout << "Caricamento completato" << endl;
        f_in.close();
    }
    else {                      //è accettabile che non ci sia alcun database (al primo avvio)
        cout << "Nessun database e' stato caricato. Ne verra' creato uno nuovo" << endl;
    }

    this-> _changes_flag=false;
}

//Legge la query impartita dall'utente tramite terminale
string DatabaseManager::readUntil (char last_char) {        //last_char è l'ultimo carattere
    string output;
    char c;
    bool text_flag = false;         //vero se viene aperto un testo tramite "
    bool char_flag = false;         //vero se viene aperto un carattere tramite '
    bool backslash_flag = false;    //cambia stato quando viene scritto un backslash, altrimenti falso
    bool error = false;             //true se un backslash viene sguito da un carattere non accettabile

    do {
        c = getchar();
        if ( c=='"' && !backslash_flag && !char_flag ) {    //condizione di apertura/chiusura di un testo
            text_flag =! text_flag;
        }
        if ( c=='\'' && !backslash_flag && !text_flag ) {   //condizione di apertura/chiusura di un char
            char_flag =! char_flag;
        }

        if ( char_flag || text_flag ) {
            if ( backslash_flag ) {     //se i caratteri precendenti sono un numero dispari di backslash
                switch ( c ) {          //gli unici caratteri accettabili sono i vari case
                    case 'n':
                        c = '\n';
                        break;
                    case 't':
                        c = '\t';
                        break;
                    case '"':           //è accettabile solo dentro un text
                        if ( char_flag ){
                            if(!error)
                                cout << output;
                            cout << "\033[1;31m" << '\\' << "\033[0m";
                            error = true;
                        }else
                            output.push_back('\\');
                        break;
                    case '\'':          //è accettabile solo dentro un char
                        if ( text_flag ){
                            if(!error)
                                cout << output;
                            cout << "\033[1;31m" << '\\' << "\033[0m";
                            error = true;
                        }else
                            output.push_back('\\');
                        break;
                    case '\\':
                        output.push_back('\\');
                        break;
                    default:
                        if(!error)
                            cout << output;
                        cout << "\033[1;31m" << '\\' << "\033[0m";
                        error = true;
                }
            }
            if (c == '\\') {
                backslash_flag = !backslash_flag;
            } else backslash_flag = false;
        }
        else {      //all'infuori di char e text, il carattere viene reso maiuscolo per avere la case insensitive
            backslash_flag = false;
            c = toupper(c);
        }
        if ( !backslash_flag ) {
            if(error)
                cout << c;
            output.push_back(c);    //il carattere viene salvato in output, tranne nel caso in cui sia un backslash dispari
        }
    } while ( c!=last_char || text_flag || char_flag ); //la lettura continua finchè non trova il last_char fuori da text e char

    if ( error ) {
        cout << endl;
        throw BackslashError();
    }
    return output;
}

//esegue lettura, analisi ed esecuzione della query impartita
bool DatabaseManager::query () {
    bool exit_flag = false;
    int n;  //contiene il numero di modifiche apportate da una query DELETE o UPDATE
    try {
        string input = readUntil(';');  //esegue la lettura della query
        RegexOutput my_query = _input_processor.functionIdentifier ( input );   //riconosce la query e salva le informazioni necessarie
        switch (my_query.my_command) {  //a seconda della query, esegue il relativo metodo della classe database
            case CREATE:
                _my_database.createTableDB ( my_query.organized_input );
                cout << "Tabella creata" << endl;
                this-> _changes_flag = true;
                break;
            case DROP:
                _my_database.dropDB ( my_query.organized_input.front() );
                cout << "Tabella eliminata" << endl;
                this-> _changes_flag = true;
                break;
            case INSERT:
                _my_database.insertIntoTableDB ( my_query.organized_input );
                cout << "Inserimento effettuato" << endl;
                this-> _changes_flag = true;
                break;
            case DELETE:
                n = _my_database.deleteFromDB ( my_query.organized_input );
                switch (n) {
                    case 0:
                        cout << "Nessun record e' stato eliminato" << endl;
                        break;
                    case 1:
                        cout << "E' stato eliminato un record" << endl;
                        break;
                    default:
                        cout << "Sono stati eliminati " << n << " records" << endl;
                }
                if ( n>0 ) {
                    this-> _changes_flag = true;
                }
                break;
            case TRUNCATE:
                _my_database.truncateDB ( my_query.organized_input.front() );
                cout << "Tabella svuotata" << endl;
                this-> _changes_flag = true;
                break;
            case UPDATE:
                n = _my_database.updateDB ( my_query.organized_input );
                switch (n) {
                    case 0:
                        cout << "Nessun record e' stato aggiornato" << endl;
                        break;
                    case 1:
                        cout << "E' stato aggiornato un record" << endl;
                        break;
                    default:
                        cout << "Sono stati aggiornati " << n << " records" << endl;
                }
                if ( n>0 ) {
                    this-> _changes_flag = true;
                }
                break;
            case SELECT:
                _my_database.selectFromDB ( my_query.organized_input );
                break;
            case QUIT:
                exit_flag = true;
                break;
            default:
                cout << "Errore";
        }
    }
    catch ( exception &e ) {
        cerr << e.what() << endl;
    }

    return exit_flag;   //true solo con la query QUIT
}

//scrive il database sul file di salvataggio
void DatabaseManager::save () {
    ofstream f_out;
    char c, option = '\0';

    if (this-> _changes_flag) {     //se sono state apportate modifiche al database
        while (option == '\0') {    //viene chiesto all'utente se desidera salvare i cambiamenti
            cout << "Salvare le modifiche? y/n" << endl;
            cin >> option;
            cin.get(c);
            if (c != '\n') {
                option = '\0';
                do { cin.get(c); }
                while (c != '\n');
            }
            else option = tolower(option);

            switch (option) {
                case 'y':   //se l'utente intende salvare
                    f_out.open( saving_file );
                    if (!f_out.is_open()) {
                        throw OpeningFileError();
                    }
                    _my_database.writeDatabase(f_out);
                    f_out.close();
                    cout << "Il database e' stato salvato" << endl;
                    break;
                case 'n':
                    cout << "Nessuna modifica e' stata apportata" << endl;
                    break;
                default:
                    option='\0';
                    cout << "Opzione non accettabile" << endl << endl;
            }
        }
    }
    else {
        cout << "Nessuna query ha modificato il database" << endl;
    }
}