//
// Created by Avalle Dario, De Carlo Francesca, Fagnani Pietro
//

#ifndef PROGETTO_DATE_H
#define PROGETTO_DATE_H

#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>

using namespace std;

class Date {
public:
    Date();
    Date(const int &d, const int &m, const int &y);
    string str() const;
    bool operator== ( const Date & to_compare ) const;
    bool operator!= ( const Date & to_compare ) const;
    bool operator> ( const Date & to_compare ) const;
    bool operator< ( const Date & to_compare ) const;
    friend std::ostream& operator<< ( std::ostream& stream, const Date& d );
    friend std::istream& operator>> ( std::istream& stream, Date &d );

private:
    int _day;
    int _month;
    int _year;
};

#endif //PROGETTO_DATE_H